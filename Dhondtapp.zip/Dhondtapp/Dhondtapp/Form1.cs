﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Dhondt;

namespace Dhondtapp
{
    public partial class Form1 : Form
    {
        private TextBox textBox = new TextBox();
        private List<Button> buttons;
        private List<string> gombNevek = new List<string>() { "File kiválasztása", "Elindít", "Dolgozz kigenerált file-al" };
        private string filePath;

        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
            this.Resize += Form1_Resize;
            this.Text = "D'hondt app";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MenuGen();
            CenterControls();
        }

        private void MenuGen()
        {
            TextBoxGen();
            ButtonsGen();
            LabelGen("D'Hondtrendszer", 10);
        }

        private void LabelGen(string text, int fontSize)
        {
            Label label = new Label();
            label.Text = text;
            this.Controls.Add(label);
        }

        private void TextBoxGen()
        {
            textBox.Size = new Size(500, 100);
            textBox.Anchor = AnchorStyles.None;
            textBox.Enabled = false;
            this.Controls.Add(textBox);
        }

        private void ButtonsGen()
        {
            buttons = new List<Button>();

            for (int i = 0; i < 3; i++)
            {
                Button button = new Button();
                button.Text = gombNevek[i];
                button.Size = new Size(250, 30);
                button.Anchor = AnchorStyles.None;
                this.Controls.Add(button);
                buttons.Add(button);
                button.Enabled = i == 1 ? false : true;
                button.Click += new EventHandler(Button_Click);
            }
        }

        private void CenterControls()
        {
            if (textBox != null && buttons != null && buttons.Count > 0)
            {
                int centerX = this.ClientSize.Width / 2;
                int centerY = this.ClientSize.Height / 2;

                textBox.Location = new Point(centerX - textBox.Width / 2, centerY - textBox.Height / 2 - 50);

                int buttonOffset = 0;
                foreach (Button button in buttons)
                {
                    button.Location = new Point(centerX - button.Width / 2, centerY - button.Height / 2 + buttonOffset);
                    buttonOffset += 50;
                }
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;

            if (clickedButton.Text == "File kiválasztása")
            {
                FileKivalaszt();
            }
            else if (clickedButton.Text == "Elindít")
            {
                Elindit();
            }
            else if (clickedButton.Text == "Dolgozz kigenerált file-al")
            {
                GenFileRun();
            }
        }

        private void FileKivalaszt()
        {
            OpenFileDialog opDia1 = new OpenFileDialog();
            opDia1.Title = "Válassz ki egy filet!";
            if (opDia1.ShowDialog() == DialogResult.OK)
            {
                buttons[1].Enabled = true;
                textBox.Text = opDia1.SafeFileName;
                filePath = opDia1.FileName;
            }
            else
            {
                textBox.Text = "Hiba vagy nincs kiválasztott fájl.";
            }
        }

        private void Elindit()
        {
            ClearFormContent();
            Szimulacio sz = new Szimulacio(filePath);
            DataGridView dataGridView = new DataGridView();
            this.Controls.Add(dataGridView);
            sz.FirstRun(dataGridView);
            FirstAndLastNav(VisszaAMenube, SecondTable, 0);

        }
        
        private void FirstAndLastNav(Action backAction, Action move, int fol)
        {
            
            FlowLayoutPanel flowLayoutPanel = CreateFlowLayoutPanel();

            Button b1 = CreateButton("Vissza a menübe");
            b1.Width = 100;
            b1.Click += (sender, e) => backAction.Invoke();
            flowLayoutPanel.Controls.Add(b1);

            Button b2 = fol == 0 ? CreateButton("Következő") : CreateButton("Előző");
            b2.Width = 100;
            b2.Click += (sender,e) => move.Invoke();
            flowLayoutPanel.Controls.Add(b2);

            this.Controls.Add(flowLayoutPanel);
        }

        private void TableNav(Action backAction, Action nextAction, Action previousAction)
        {
            FlowLayoutPanel flowLayoutPanel = CreateFlowLayoutPanel();

            Button backButton = CreateButton("Vissza a menübe");
            backButton.Width = 100;
            backButton.Click += (sender, e) => backAction.Invoke();
            flowLayoutPanel.Controls.Add(backButton);

            Button nextButton = CreateButton("Következő");
            nextButton.Width = 100;
            nextButton.Click += (sender, e) => nextAction.Invoke();
            flowLayoutPanel.Controls.Add(nextButton);

            Button previousButton = CreateButton("Előző");
            previousButton.Width = 100;
            previousButton.Click += (sender, e) => previousAction.Invoke();
            flowLayoutPanel.Controls.Add(previousButton);

            this.Controls.Add(flowLayoutPanel);
        }
     
        private void SecondTable()
        {
            ClearFormContent();
            Szimulacio sz = new Szimulacio(filePath);
            DataGridView dataGridView = new DataGridView();
            sz.SecondRun(dataGridView);
            this.Controls.Add(dataGridView);
            TableNav(VisszaAMenube, ThirdTable, Elindit);
        }

        private void ThirdTable()
        {
            ClearFormContent();
            Szimulacio sz = new Szimulacio(filePath);
            DataGridView dataGridView = new DataGridView();
            sz.ThirdTableKiir(ref dataGridView);
            this.Controls.Add(dataGridView);
            TableNav(VisszaAMenube, FourthTable, SecondTable);
        }

        private void FourthTable()
        { 
            ClearFormContent();
            Szimulacio sz = new Szimulacio(filePath);
            DataGridView dataGridView = new DataGridView();
            sz.FourthTable(ref dataGridView);
            this.Controls.Add(dataGridView);
            TableNav(VisszaAMenube,FifthTable,ThirdTable);
        }

        private void FifthTable()
        {
            ClearFormContent();
            Szimulacio szimulacio = new Szimulacio(filePath);
            DataGridView dataGridView = new DataGridView();
            szimulacio.FifthTableKiir(ref dataGridView);
            this.Controls.Add(dataGridView);
            TableNav(VisszaAMenube,SixthTable,FourthTable);
        }

        private void SixthTable()
        {
            ClearFormContent();
            Szimulacio sz = new Szimulacio(filePath);
            DataGridView dataGridView = new DataGridView();
            sz.SixthTableKiir(ref dataGridView);
            this.Controls.Add(dataGridView);
            FirstAndLastNav(VisszaAMenube, FifthTable, 1);
        }
        
        private Button CreateButton(string buttonText)
        {
            Button button = new Button();
            button.Text = buttonText;
            return button;
        }

        private void VisszaAMenube()
        {
            ClearFormContent();
            textBox = new TextBox();
            MenuGen();
            CenterControls();
        }

        private FlowLayoutPanel CreateFlowLayoutPanel()
        {
            FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel();
            flowLayoutPanel.Dock = DockStyle.Top;
            flowLayoutPanel.Height = this.Height / 15;
            flowLayoutPanel.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel.Padding = new Padding(0, (flowLayoutPanel.Height - 15) / 3, 0, 0);
            return flowLayoutPanel;
        }

        private void GenFileRun()
        {
            ClearFormContent();
            TextBox partSzam = new TextBox();
            TextBox szavazatSzam = new TextBox();
            TextBox partokSzama = new TextBox();
            TextBox nemZetisegiekSzama = new TextBox();
            Button GenOkButton = new Button();
            partSzam.Size = new Size(100, 20);
            partSzam.Location = new Point(50, 50);
            szavazatSzam.Size = new Size(100, 20);
            szavazatSzam.Location = new Point(50, 80);
            this.Controls.Add(partSzam);
            this.Controls.Add(szavazatSzam);
            CenterControls();
        }

        private void ClearFormContent()
        {
            foreach (Control control in this.Controls)
            {
                control.Dispose();
            }
            this.Controls.Clear();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            CenterControls();
        }

    }
}
